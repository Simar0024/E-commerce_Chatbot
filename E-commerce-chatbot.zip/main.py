import openai
import os
from flask import Flask, render_template_string, request

openai.api_key = os.environ['my_key']

def chatbot(articles):
  response = openai.chat.completions.create(
      model='gpt-3.5-turbo',
      messages=[{
          'role': 'system',
          'content': 'You are a helpful assistant'},  
          {'role':'user',
          'content':f'Give me details of the entered articles by describing the available sizing options, styles, prices in INR for both male and female {articles}. Also, try to provide a link to that article on e-commerce websites such as amazon.in, flipkart.com'
      },
          {'role':'system',
           'content':f'You are a friendly and cooperative assistant.You are an e-commerce chatbot and have access to all kinds of e-commerce information including wearables, electronics, accessories , home appliances etc.Try to fetch the details of {articles} and ask for any improvements.'
               }])
  return response.choices[0].message.content
  
app = Flask('__name__')
@app.route('/', methods=['GET', 'POST'])

def view():
  output = ""
  if request.method == 'POST':
    temp = request.form['articles']
    output = chatbot(temp)
  return render_template_string('''
    <!DOCTYPE html>
    <html>
        <head>
            <meta name="viewport" content="width=device-width,initial-scale=1.0">
            <title>My E-Commerce Chatbot</title>
            <style>
            body{
                background-color: beige;
            }

            .outer{
                width: 100%;
                font-size: large;
                font-family: Arial, Helvetica, sans-serif;
                border: 50px;
                padding: 25px;
            }

            .center{
                font-size: medium;
                display: inline-block;
                width: 50%;
            }

            .myinput{
                color: brown;
                width: 100%;
                border: 1px solid light-grey;
                height: 25px;
                border-radius: 5px;
                padding: 2px;
            }

            .mybutton{
                background-color: cornflowerblue;
                border: 1px solid black;
                border-radius: 10px;
            }

            .myoutput{
                font-size: 16px;
                color: black;
            }

            .firstoutput{
                border: 1px solid grey;
                width: 80%;
                padding: 5px 0px 0px 5px;
            }

            .secondoutput{
                border: 1px solid grey;
                width: 80%;
                padding: 5px 0px 0px 5px;
            }
                
            </style>
            <script>
            
            async function sendMessage(){
            
            const articles = document.querySelector('#articles').value;
            const output = document.querySelector('#output');
            output.textContent = 'Just a minute while I fetch the products...';
            const response = await fetch('/generate', {
            method:'POST',
            body: new FormData(document.querySelector('#chat-form'))});
            const final = await response.text();
            output.textContent = final;
            }
            
            </script>
        </head>
        
        <body>
            <div class="outer">
                <h1>Welcome to E-Commerce Chatbot !!</h1>
                <p>Make your shopping experience fun.</p>
            <form id="chat-form" onsubmit="event.preventDefault(); sendMessage();" class="myform">
            <div class="center">
            <label>Type in the products you are looking for :</label>
            <p> </p>
                <input type="text" class="myinput" id="articles" 
                name="articles" placeholder="What would you like to purchase?" required>
            </div>
            <p> </p>
            <button type="submit" class="mybutton"> Get </button>
            </form>
            <p> <p>
            <div class="myoutput">
            <div class="firstoutput">
            Results found:
            </div>
            <div class="secondoutput">
            <pre id="output" style="white-space: pre-wrap;">{{output}}</pre>
            </div>
            </div>
            </div>
        </body>
    </html>
    ''', output=output)
  
@app.route('/generate',methods=['POST'])

def result():
  myArticles = request.form['articles']
  return chatbot(myArticles)

if __name__ == '__main__':
  app.run(host='0.0.0.0', port=8080)
  